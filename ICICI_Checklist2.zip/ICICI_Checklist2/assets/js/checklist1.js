/* IDCPMS — Checklist 1 (Domain Discovery) renderer */

(function () {
  const state = {
    activeFilter: "all",
    openDomain: null,
    openMenu: null,
    customDomains: []   // user-added via "+ Add Domain"
  };

  function allDomains() {
    return window.DOMAINS.concat(state.customDomains);
  }

  function caretSvg() {
    return `<svg width="14" height="14" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg"><path d="M6 4l4 4-4 4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
  }
  function dotsSvg() {
    return `<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/></svg>`;
  }

  function recomputeStats() {
    const domains = allDomains();
    const total = domains.reduce((s, d) => s + d.items.length, 0);
    const reviewed = domains.reduce((s, d) => s + d.items.filter(i => i.reviewed).length, 0);
    const pending = total - reviewed;
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set("stat-domains", domains.length);
    set("stat-total", total);
    set("stat-reviewed", reviewed);
    set("stat-pending", pending);
  }

  function isFilterMatch(d) {
    return state.activeFilter === "all" || d.id === state.activeFilter;
  }

  function renderDomain(d, idx) {
    const theme = window.DOMAIN_THEME[d.id] || { iconBg: "#eee", iconColor: "#555", icon: "•" };
    const reviewed = d.items.filter(i => i.reviewed).length;
    const open = state.openDomain === d.id;

    const itemsHtml = d.items.map((it, i) => {
      const flagged = false; // c1 items don't carry confidence
      const reviewedCls = it.reviewed ? "reviewed" : "";
      const checked = it.reviewed ? "checked" : "";
      const menuOpen = state.openMenu === d.id + ":" + i;
      return `
        <div class="point-row ${reviewedCls} ${flagged ? "flagged" : ""}" data-domain="${d.id}" data-idx="${i}">
          <input type="checkbox" class="chk" ${checked} data-action="toggle"/>
          <div class="body">
            <div class="text" contenteditable="true" spellcheck="false">${escapeHtml(it.text)}</div>
            <div class="meta">Domain — <span class="domain-name">${escapeHtml(d.name)}</span></div>
          </div>
          <span class="source-pill">${escapeHtml(it.source)}</span>
          <div class="row-menu">
            <button class="menu-btn" data-action="menu" aria-label="Row actions">${dotsSvg()}</button>
            <div class="menu-pop ${menuOpen ? "open" : ""}">
              <div class="submenu">
                <div class="label">Change domain</div>
                ${allDomains().filter(x => x.id !== d.id).map(x =>
                  `<button data-action="move" data-target="${x.id}">${escapeHtml(x.name)}</button>`
                ).join("")}
              </div>
              <div class="submenu">
                <button class="danger" data-action="delete">Delete point</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join("");

    return `
      <div class="domain-card ${open ? "open" : ""}" data-domain="${d.id}">
        <div class="domain-head" data-action="toggle-domain">
          <span class="icon-tile" style="background:${theme.iconBg};color:${theme.iconColor};">${theme.icon}</span>
          <span class="name">${escapeHtml(d.name)}</span>
          <span class="count">${reviewed}/${d.items.length}</span>
          <span class="caret">${caretSvg()}</span>
        </div>
        <div class="domain-body">
          ${itemsHtml || `<div class="text-muted text-small" style="padding:10px 6px;">No items in this domain yet.</div>`}
        </div>
      </div>
    `;
  }

  function render() {
    const host = document.getElementById("cl1-list");
    if (!host) return;
    const visible = allDomains().filter(isFilterMatch);
    host.innerHTML = visible.map(renderDomain).join("") + `
      <div class="add-domain-row">
        <button id="add-domain-btn">+ Add Domain</button>
      </div>
    `;
    bind();
    recomputeStats();
  }

  function bind() {
    const host = document.getElementById("cl1-list");
    if (!host) return;
    host.addEventListener("click", onClick);
    host.addEventListener("change", onChange);
    host.addEventListener("input", onInput);
    const addBtn = document.getElementById("add-domain-btn");
    if (addBtn) addBtn.onclick = onAddDomain;
  }

  function onClick(e) {
    const action = e.target.closest("[data-action]");
    if (!action) return;
    const domainEl = action.closest(".domain-card");
    const rowEl = action.closest(".point-row");
    const a = action.dataset.action;

    if (a === "toggle-domain") {
      const id = domainEl.dataset.domain;
      state.openDomain = state.openDomain === id ? null : id;
      state.openMenu = null;
      render();
      return;
    }
    if (a === "menu") {
      e.stopPropagation();
      const key = rowEl.dataset.domain + ":" + rowEl.dataset.idx;
      state.openMenu = state.openMenu === key ? null : key;
      render();
      return;
    }
    if (a === "move") {
      const target = action.dataset.target;
      const fromId = rowEl.dataset.domain;
      const idx = parseInt(rowEl.dataset.idx, 10);
      moveItem(fromId, idx, target);
      state.openMenu = null;
      render();
      return;
    }
    if (a === "delete") {
      const fromId = rowEl.dataset.domain;
      const idx = parseInt(rowEl.dataset.idx, 10);
      deleteItem(fromId, idx);
      state.openMenu = null;
      render();
      return;
    }
  }

  function onChange(e) {
    if (e.target.matches(".chk")) {
      const row = e.target.closest(".point-row");
      const id = row.dataset.domain;
      const idx = parseInt(row.dataset.idx, 10);
      const d = findDomain(id);
      if (d) d.items[idx].reviewed = e.target.checked;
      render();
    }
  }

  function onInput(e) {
    if (e.target.matches(".text[contenteditable]")) {
      const row = e.target.closest(".point-row");
      const id = row.dataset.domain;
      const idx = parseInt(row.dataset.idx, 10);
      const d = findDomain(id);
      if (d) d.items[idx].text = e.target.textContent;
      // Don't re-render on every keystroke — just update stats.
    }
  }

  function findDomain(id) {
    return allDomains().find(d => d.id === id);
  }

  function moveItem(fromId, idx, toId) {
    const from = findDomain(fromId);
    const to = findDomain(toId);
    if (!from || !to) return;
    const [item] = from.items.splice(idx, 1);
    to.items.push(item);
  }

  function deleteItem(id, idx) {
    const d = findDomain(id);
    if (!d) return;
    d.items.splice(idx, 1);
  }

  function onAddDomain() {
    const name = prompt("Add a new custom domain:");
    if (!name) return;
    const id = "custom-" + Date.now();
    state.customDomains.push({
      id,
      name: name.trim(),
      items: [],
      custom: true
    });
    window.DOMAIN_THEME[id] = { iconBg: "var(--brand-orange-l)", iconColor: "var(--brand-orange-d)", icon: "✦" };
    render();
  }

  function bindFilters() {
    const bar = document.getElementById("cl1-filters");
    if (!bar) return;
    bar.addEventListener("click", e => {
      const btn = e.target.closest("button[data-filter]");
      if (!btn) return;
      bar.querySelectorAll("button").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      state.activeFilter = btn.dataset.filter;
      render();
    });
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }

  /* Close menus on outside click */
  document.addEventListener("click", e => {
    if (e.target.closest("[data-action='menu']")) return;
    if (e.target.closest(".menu-pop")) return;
    if (state.openMenu !== null) {
      state.openMenu = null;
      render();
    }
  });

  document.addEventListener("DOMContentLoaded", () => {
    bindFilters();
    render();
  });

  window.Checklist1 = { render, recomputeStats };
})();
