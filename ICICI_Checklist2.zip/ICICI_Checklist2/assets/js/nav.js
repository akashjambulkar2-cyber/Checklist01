/* IDCPMS — auth gate, app bar, shared helpers */

(function () {
  const PUBLIC_PAGES = ["index.html", ""];
  const path = location.pathname.split("/").pop();

  function isAuthed() {
    try { return sessionStorage.getItem("idcpmsAuth") === "1"; }
    catch (_) { return false; }
  }

  function gate() {
    if (PUBLIC_PAGES.includes(path)) return;
    if (!isAuthed()) {
      location.replace("index.html");
    }
  }

  function logout() {
    try { sessionStorage.removeItem("idcpmsAuth"); } catch (_) {}
    location.replace("index.html");
  }

  function renderAppBar(opts) {
    const host = document.getElementById("app-bar");
    if (!host) return;
    const title = (opts && opts.title) || "IDCPMS · IMPS Compliance & Classification Suite";
    host.innerHTML = `
      <div class="app-bar">
        <div class="inner">
          <span class="logo-tile tile-orange tile-sm">IC</span>
          <div class="title">IDCPMS <small>· IMPS Compliance &amp; Classification Suite</small></div>
          <div class="spacer"></div>
          <span class="user-chip">
            <span class="avatar">AJ</span>
            <span>Akash Jambulkar · Audit</span>
            <button id="logout-btn" title="Sign out">Sign out</button>
          </span>
        </div>
      </div>
    `;
    const btn = document.getElementById("logout-btn");
    if (btn) btn.addEventListener("click", logout);
  }

  function confidenceClass(score) {
    if (score >= 85) return "good";
    if (score >= 60) return "warn";
    return "bad";
  }

  function reviewFlag(score) {
    return score < 70;
  }

  /* Stub a download — used by export.html */
  function fakeDownload(filename, mime, body) {
    const blob = new Blob([body || ""], { type: mime || "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 100);
  }

  /* Click-outside helper for popovers */
  function attachOutsideClick(closeFn) {
    function handler(e) {
      const open = document.querySelector(".menu-pop.open");
      if (!open) return;
      if (open.contains(e.target)) return;
      const trigger = e.target.closest(".menu-btn");
      if (trigger && trigger.parentElement === open.parentElement) return;
      closeFn();
    }
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }

  window.IDCPMS = {
    gate,
    logout,
    renderAppBar,
    confidenceClass,
    reviewFlag,
    fakeDownload,
    attachOutsideClick,
    isAuthed
  };

  /* Run gate immediately */
  gate();
})();
