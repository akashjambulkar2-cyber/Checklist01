/* IDCPMS — hard-coded sample data for the IMPS prototype */

window.SOURCE_DOCS = [
  "IMPS OC 127 / FY 25-26",
  "IMPS Settlement Process",
  "IMPS Product Booklet",
  "imps.docx"
];

/* Domain palette — keys match domain.id */
window.DOMAIN_THEME = {
  regulatory:    { pillClass: "pill-soft-purple", iconBg: "#EDE6F8", iconColor: "#5C3BB1", icon: "⚖" },
  technology:    { pillClass: "pill-soft-blue",   iconBg: "#E7EFFB", iconColor: "#2A5DBE", icon: "💻" },
  settlement:    { pillClass: "pill-soft-teal",   iconBg: "#DFF1EE", iconColor: "#1E7E72", icon: "₹" },
  cybersecurity: { pillClass: "pill-soft-rose",   iconBg: "#FCE2EB", iconColor: "#B0275A", icon: "🔒" },
  customer:      { pillClass: "pill-soft-amber",  iconBg: "#FBEFD6", iconColor: "#A9690A", icon: "👤" }
};

/* ------------------------------------------------------------------ */
/* CHECKLIST 1 — domain accordion                                      */
/* 5 domains · 34 items · 1 reviewed · 33 pending                       */
/* ------------------------------------------------------------------ */
window.DOMAINS = [
  {
    id: "regulatory",
    name: "Regulatory Compliance & Authorisation",
    items: [
      { text: "Eligibility — entity must hold a valid banking or Prepaid Payment Instrument (PPI) licence from RBI to participate in IMPS; 967 members are currently live including banks & PPIs.", source: "imps.docx", reviewed: false },
      { text: "All members must issue a letter of authority to RBI (DAD Mumbai) authorising NPCI to credit and debit their settlement account for IMPS transactions settled in the IMPS MNSB file.", source: "IMPS Settlement Process / §1", reviewed: false },
      { text: "Direct membership requires an RTGS membership with RBI; entities without RTGS membership can only participate as indirect / sub-members through a sponsor bank.", source: "IMPS Product Booklet / §5", reviewed: false },
      { text: "Any member offering IMPS through the mobile channel must hold a valid Mobile Banking Licence from RBI.", source: "IMPS Product Booklet / §5", reviewed: false },
      { text: "Non-banking institutions can join IMPS only if authorised by RBI as a payment system service provider; settlement is processed on the books of an existing direct-member sponsor bank via RTGS.", source: "IMPS Product Booklet / §5", reviewed: false },
      { text: "Auto Acceptance & Rejection of chargeback basis TCC & Returns is effective in IRCS from 27-Aug-2025; applicable only to deemed-approved P2P chargebacks above ₹25,000 via bulk upload / ODIR (not front-end).", source: "IMPS OC 127 / FY 25-26", reviewed: false },
      { text: "Applicable Acts — Payment & Settlement Systems Act 2007, PMLA 2002, Section 25 of the Companies Act 1956, and the Indian Arbitration & Conciliation Act 1996 govern IMPS operations.", source: "IMPS Product Booklet / §7", reviewed: false },
      { text: "Maximum per-transaction value on IMPS is ₹5,00,000 (5 lakh) for retail customers as per RBI guidelines.", source: "IMPS Product Booklet / §4", reviewed: false }
    ]
  },
  {
    id: "technology",
    name: "Technology & Systems",
    items: [
      { text: "P2P fund transfer uses Mobile Number + MMID (7-digit Mobile Money Identifier linked to a unique bank account).", source: "IMPS Product Booklet / §3", reviewed: false },
      { text: "P2A fund transfer uses Beneficiary Account Number + 11-digit alphanumeric IFSC code as the routing identifier (used when the beneficiary's mobile is not registered for IMPS).", source: "IMPS Product Booklet / §3", reviewed: true },
      { text: "Each MMID is a 7-digit code linked to a unique mobile number; different MMIDs can be linked to the same mobile number to support multiple accounts of the same customer.", source: "imps.docx", reviewed: false },
      { text: "IMPS is available 24×7×365 (including holidays) and is channel-agnostic — accessible via mobile banking, internet banking, ATM, branch and SMS.", source: "IMPS Product Booklet / §2", reviewed: false },
      { text: "Supported transfer combinations include account-to-account, account-to-wallet, and wallet-to-account fund transfers within the IMPS ecosystem.", source: "IMPS Product Booklet / §2", reviewed: false },
      { text: "Non-financial transactions supported by IMPS — Check Status (for Deemed Approved transactions) and Name Inquiry (using Account+IFSC or MMID+Mobile).", source: "IMPS Product Booklet / §3", reviewed: false },
      { text: "Member onboarding sequence — development per latest NPCI specs, certification request on the C-flow portal, two rounds of testing (Comfort + UAT) in the Certification Zone simulator, and document submission for Go-Live.", source: "IMPS Product Booklet / §6", reviewed: false },
      { text: "NPCI is the owner, operator, service provider and co-ordinator of the IMPS Network and may operate the network directly or through third-party service providers.", source: "IMPS Product Booklet / §6", reviewed: false }
    ]
  },
  {
    id: "settlement",
    name: "Settlement & Reconciliation",
    items: [
      { text: "NPCI acts as the clearing & settlement agency for inter-bank settlement of IMPS transactions between Remitter and Beneficiary members participating in the IMPS network.", source: "IMPS Settlement Process / §1", reviewed: false },
      { text: "NPCI calculates the net debit / credit position for each member based on total netting of acquiring, issuing transactions and adjustments, and posts entries via the IMPS MNSB (Multi-lateral Net Settlement Batch) file at RBI.", source: "IMPS Settlement Process / §1", reviewed: false },
      { text: "Members in net-debit position must hold sufficient funds in their RTGS settlement account at RBI to honour the settlement obligation sent by NPCI.", source: "IMPS Settlement Process / §1", reviewed: false },
      { text: "Members must periodically review daily settlement amount trends and pre-fund the RTGS settlement account to avoid out-of-fund situations during settlement runs.", source: "IMPS Settlement Process / §1", reviewed: false },
      { text: "All IMPS transactions are settled in Indian Rupee (INR) only — no multi-currency settlement is supported.", source: "IMPS Settlement Process / §3", reviewed: false },
      { text: "IMPS provides daily settlement reports in Back-office application format round-the-clock; member banks must reconcile against their own reports and raise required adjustments on the back-office portal for exceptional transactions.", source: "IMPS Settlement Process / §2", reviewed: false }
    ]
  },
  {
    id: "cybersecurity",
    name: "Cybersecurity & Risk",
    items: [
      { text: "Beneficiary Account Validation API and Check Status API must be used by member banks to validate the beneficiary's account before financial transactions and to surface real-time transaction status to customers.", source: "IMPS Product Booklet / §4", reviewed: false },
      { text: "Each member must maintain records of all IMPS transactions for the minimum period stipulated by law; records of all disputed transactions must be retained until the dispute is fully resolved.", source: "IMPS Settlement Process / §4", reviewed: false },
      { text: "Settlement obligation is enforced via the RBI RTGS settlement account — members must ensure adequate balance before NPCI's settlement run to prevent settlement failure.", source: "IMPS Settlement Process / §1", reviewed: false },
      { text: "Members must collaboratively endeavour to settle discrepancies in the dispute management process per the IMPS Operating & Settlement Guidelines (OSG); disputes left unaccepted/unrejected within TAT are auto-closed on a deemed acceptance basis.", source: "IMPS Settlement Process / §4", reviewed: false },
      { text: "Members must periodically review NPCI operating circulars to ensure compliance with any updates to dispute resolution rules, TAT changes, and process amendments.", source: "IMPS Settlement Process / §4", reviewed: false },
      { text: "Indian Arbitration & Conciliation Act, 1996 governs arbitration of IMPS disputes that escalate beyond NPCI's internal review panels.", source: "IMPS Product Booklet / §7", reviewed: false }
    ]
  },
  {
    id: "customer",
    name: "Customer Experience & Disputes",
    items: [
      { text: "IMPS Dispute Lifecycle — (1) Chargeback raised by remitting bank → (2) Beneficiary bank Accept / Re-present chargeback → (3) Pre-Arbitration raised → (4) Accept / Reject pre-arbitration → (5) Arbitration if unresolved.", source: "IMPS Settlement Process / §4", reviewed: false },
      { text: "Standardised TAT for all IMPS dispute actions (raise Chargeback, TCC, RET) is 45 days; auto acceptance / rejection follows the same TAT.", source: "IMPS OC 127 / FY 25-26", reviewed: false },
      { text: "Auto chargeback acceptance applies only to deemed-approved P2P chargebacks of RC-08 type above ₹25,000; the IRCS system rejects the chargeback and processes the corresponding TCC/RET in the next settlement cycle.", source: "IMPS OC 127 / FY 25-26", reviewed: false },
      { text: "Two new dispute reason codes are introduced — 9886 (Auto Chargeback Acceptance, IA flag) and 9887 (Auto Chargeback Representment, IR flag) — effective 27-Aug-2025.", source: "IMPS OC 127 / FY 25-26", reviewed: false },
      { text: "Online Dispute Resolution (ODR) provides — seamless issue resolution, transaction status check option to customers, complaint management workflow, and auto status update of pending transactions.", source: "IMPS Settlement Process / §4", reviewed: false },
      { text: "Disputes referred to arbitration are first reviewed by the NPCI Review Panel (NRP); if further challenged, the Panel for Dispute Resolution (PRD) issues the final decision.", source: "IMPS Settlement Process / §4", reviewed: false }
    ]
  }
];

/* ------------------------------------------------------------------ */
/* CHECKLIST 2 — IDBI IMPS document classification & audit programme   */
/* 22 sections · 13 available · 9 partial · 0 gap · avg confidence 88% */
/* ------------------------------------------------------------------ */
window.SECTIONS = [
  {
    id: "s01",
    area: "AML / KYC",
    docTitle: "2.3 KYC & AML compliance",
    docSub: "Sec 2",
    regulatory: "PMLA 2002 + RBI KYC Master Directions — full-KYC before IMPS access; STR/CTR filing",
    whatToTest: "Verify only full-KYC customers have IMPS access; validate STR & CTR filing process",
    howToTest: [
      "Extract customer list with IMPS access vs KYC status from CBS.",
      "Sample 25 accounts; verify no partial-KYC accounts have IMPS enabled.",
      "Obtain FIU-IND STR/CTR filing register; verify timelines and completeness."
    ],
    dataRequired: ["CBS KYC extract", "AML alert log", "STR/CTR register", "FIU-IND acknowledgements"],
    avail: "ok",
    confidence: 91,
    method: "Test"
  },
  {
    id: "s02",
    area: "AML / KYC",
    docTitle: "3.2 User eligibility validation",
    docSub: "Sec 3",
    regulatory: "RBI KYC Directions — sanctions screening; RBI caution list check before each session",
    whatToTest: "Confirm AML/sanctions screening is executed at login for all IMPS-eligible customers",
    howToTest: [
      "Review system architecture docs for screening integration.",
      "Select 10 accounts on RBI caution list; verify IMPS access is blocked.",
      "Inspect screening logs for timestamps and decision codes."
    ],
    dataRequired: ["Eligibility check logs", "RBI caution list", "Sanctions hit report", "Session audit trail"],
    avail: "partial",
    confidence: 84,
    method: "System verify"
  },
  {
    id: "s03",
    area: "Authentication",
    docTitle: "7.1 Login authentication",
    docSub: "Sec 7",
    regulatory: "RBI Internet Banking Guidelines — mandatory two-factor authentication; brute-force lockout",
    whatToTest: "Validate password hashing, lockout after failed attempts, and device fingerprinting controls",
    howToTest: [
      "Obtain password storage policy; verify hashing algorithm (bcrypt/PBKDF2) in use.",
      "Attempt >5 failed logins on test account; confirm lockout and SMS alert triggered.",
      "Log in from new device; confirm additional verification step invoked."
    ],
    dataRequired: ["Authentication DB schema", "Login failure log", "SMS dispatch log", "Device registry"],
    avail: "ok",
    confidence: 95,
    method: "Test"
  },
  {
    id: "s04",
    area: "Authentication",
    docTitle: "7.2 OTP & transaction password",
    docSub: "Sec 7",
    regulatory: "RBI guidelines on 2FA for internet banking transactions — OTP validity, single-use enforcement",
    whatToTest: "Test OTP expiry, reuse prevention, and separation of authentication service from application",
    howToTest: [
      "Capture OTP; attempt reuse after first successful use — expect rejection.",
      "Wait beyond validity period (>10 min); attempt OTP — expect expiry error.",
      "Review OTP service architecture for logical separation from app server.",
      "Inspect OTP generation logs for randomness and audit completeness."
    ],
    dataRequired: ["OTP generation log", "OTP validation log", "Architecture diagram", "Test account OTPs"],
    avail: "ok",
    confidence: 93,
    method: "Test"
  },
  {
    id: "s05",
    area: "Authentication",
    docTitle: "7.3 Session management",
    docSub: "Sec 7",
    regulatory: "RBI Cybersecurity Framework — session timeout, single-session enforcement",
    whatToTest: "Verify idle timeout, absolute session duration, and concurrent session prevention",
    howToTest: [
      "Leave session idle past timeout threshold; confirm auto-logout and redirect to login.",
      "Log in from two browsers simultaneously; verify second session terminates first.",
      "Inspect session token TTL configuration and storage."
    ],
    dataRequired: ["Session management config", "Session logs", "Concurrent session alerts"],
    avail: "partial",
    confidence: 88,
    method: "Test"
  },
  {
    id: "s06",
    area: "Authentication",
    docTitle: "7.4 Device fingerprinting",
    docSub: "Sec 7",
    regulatory: "RBI Master Direction on Digital Payment Security — device binding for high-risk transactions",
    whatToTest: "Validate device fingerprint capture, binding to user, and step-up auth on new devices",
    howToTest: [
      "Inspect device fingerprint capture code path; confirm collected attributes meet policy.",
      "Initiate IMPS from un-bound device; confirm step-up OTP triggered.",
      "Review device registry for stale entries and de-registration policy."
    ],
    dataRequired: ["Device registry table", "Fingerprint hashing algo doc", "Step-up trigger log"],
    avail: "ok",
    confidence: 90,
    method: "Test"
  },
  {
    id: "s07",
    area: "Settlement",
    docTitle: "4.1 Transaction routing & switch",
    docSub: "Sec 4",
    regulatory: "NPCI IMPS Operating Circular — ISO 8583 routing through NPCI switch",
    whatToTest: "Confirm all outward IMPS transactions route via NPCI switch with correct ISO 8583 fields",
    howToTest: [
      "Review switch configuration; verify all IMPS MTI codes are routed to NPCI host.",
      "Trace 5 sample transactions through switch logs end-to-end.",
      "Compare ISO 8583 fields populated against NPCI specification."
    ],
    dataRequired: ["Switch config", "ISO 8583 message dump", "NPCI host trace"],
    avail: "ok",
    confidence: 92,
    method: "System verify"
  },
  {
    id: "s08",
    area: "Settlement",
    docTitle: "4.2 IMPS settlement cycle",
    docSub: "Sec 4",
    regulatory: "NPCI Settlement Process — multilateral net settlement, deferred basis through RBI",
    whatToTest: "Confirm participation in NPCI multilateral net settlement and timely posting at RBI",
    howToTest: [
      "Obtain settlement file exchange schedule with NPCI; verify cut-off compliance.",
      "Compare net settlement debit/credit advice from NPCI to GL postings.",
      "Inspect failed-settlement event log for last 90 days."
    ],
    dataRequired: ["NPCI settlement files", "RBI settlement advice", "GL extract"],
    avail: "partial",
    confidence: 81,
    method: "Test"
  },
  {
    id: "s09",
    area: "Settlement",
    docTitle: "4.3 Net settlement reconciliation",
    docSub: "Sec 4",
    regulatory: "NPCI Settlement Process — daily reconciliation between switch logs and core banking",
    whatToTest: "Daily recon between switch / NPCI raw file / CBS posting; identify open breaks",
    howToTest: [
      "Pick 5 random business days; obtain three-way recon report.",
      "Identify exceptions; trace each to closure or open status.",
      "Verify ageing of unresolved breaks and escalation."
    ],
    dataRequired: ["Switch dump", "NPCI raw file", "CBS posting", "Recon report"],
    avail: "ok",
    confidence: 89,
    method: "System verify"
  },
  {
    id: "s10",
    area: "Settlement",
    docTitle: "4.4 Beneficiary credit confirmation",
    docSub: "Sec 4",
    regulatory: "IMPS Product Booklet §3 — credit confirmation back to originating bank within 30s",
    whatToTest: "Verify credit posting and acknowledgement messages are dispatched within SLA",
    howToTest: [
      "Sample 25 inward IMPS transactions; measure credit-time from message receipt.",
      "Verify ack messages sent back to originator with success code.",
      "Inspect failures and SLA breach exceptions."
    ],
    dataRequired: ["Inward IMPS log", "Credit posting timestamps", "Ack dispatch log"],
    avail: "ok",
    confidence: 91,
    method: "Test"
  },
  {
    id: "s11",
    area: "Settlement",
    docTitle: "4.5 Failed transaction reversal",
    docSub: "Sec 4",
    regulatory: "RBI Harmonisation of TAT — auto-reversal on T+1; ₹100/day compensation on delay",
    whatToTest: "Confirm auto-reversal job runs and credits customer within T+1; compensation paid on breach",
    howToTest: [
      "Identify last quarter's failed IMPS transactions; verify reversal posting date.",
      "For breaches, verify ₹100/day compensation credit posted.",
      "Inspect job schedule and exception alerting."
    ],
    dataRequired: ["Failed txn log", "Reversal posting", "Compensation register"],
    avail: "partial",
    confidence: 80,
    method: "Test"
  },
  {
    id: "s12",
    area: "Cybersecurity",
    docTitle: "5.1 Encryption in transit (TLS 1.2+)",
    docSub: "Sec 5",
    regulatory: "RBI Cybersecurity Framework — TLS 1.2 minimum for all sensitive traffic",
    whatToTest: "All IMPS traffic between bank app, NPCI switch, and CBS uses TLS 1.2 or higher",
    howToTest: [
      "Run TLS scan against all IMPS endpoints (sslscan / testssl.sh).",
      "Confirm no SSLv3/TLS 1.0/1.1 ciphers accepted.",
      "Verify certificate validity and rotation calendar."
    ],
    dataRequired: ["TLS scan reports", "Cert inventory", "Rotation calendar"],
    avail: "ok",
    confidence: 94,
    method: "System verify"
  },
  {
    id: "s13",
    area: "Cybersecurity",
    docTitle: "5.2 PII data masking",
    docSub: "Sec 5",
    regulatory: "RBI Master Direction on Customer Data Protection — masking of PAN, Aadhaar, account no.",
    whatToTest: "PII fields displayed/printed/logged are masked in non-production and per-role in production",
    howToTest: [
      "Review screen mock-ups in customer-facing channels for masking rules.",
      "Inspect application logs for any PII leakage.",
      "Test role-based reveal in admin tools."
    ],
    dataRequired: ["UI screenshots", "App log samples", "Role matrix"],
    avail: "partial",
    confidence: 84,
    method: "Test"
  },
  {
    id: "s14",
    area: "Cybersecurity",
    docTitle: "5.3 Audit logging & SIEM forwarding",
    docSub: "Sec 5",
    regulatory: "RBI Cybersecurity Framework — comprehensive audit logging for 10 years",
    whatToTest: "All security-relevant events captured and forwarded to SIEM with integrity protection",
    howToTest: [
      "Inspect log retention and immutability controls.",
      "Verify SIEM ingestion of authentication, transaction, and admin events.",
      "Trigger test events and confirm appearance in SIEM dashboard."
    ],
    dataRequired: ["Log policy", "SIEM connector config", "Test event traces"],
    avail: "ok",
    confidence: 90,
    method: "Test"
  },
  {
    id: "s15",
    area: "Cybersecurity",
    docTitle: "5.4 Vulnerability assessment & PT",
    docSub: "Sec 5",
    regulatory: "RBI Cyber Security Circular — annual VAPT with closure of critical/high findings",
    whatToTest: "Annual VAPT completed; critical/high findings closed within 30/60 days",
    howToTest: [
      "Obtain latest VAPT report and finding tracker.",
      "Verify closure timestamps for critical and high findings.",
      "Cross-check open findings against compensating controls."
    ],
    dataRequired: ["VAPT report", "Finding tracker", "Risk acceptance memos"],
    avail: "partial",
    confidence: 81,
    method: "Test"
  },
  {
    id: "s16",
    area: "Customer",
    docTitle: "6.1 Dispute & chargeback (OC 127)",
    docSub: "Sec 6",
    regulatory: "NPCI OC 127 — chargeback raise / accept / reject / pre-arbitration timelines",
    whatToTest: "Bank operates within OC 127 chargeback timelines; reason codes used correctly",
    howToTest: [
      "Sample 20 chargebacks raised in last quarter; verify timeline compliance.",
      "Inspect reason code usage against OC 127 mapping table.",
      "Verify pre-arbitration & arbitration adherence."
    ],
    dataRequired: ["Chargeback register", "OC 127 mapping", "Pre-arb log"],
    avail: "ok",
    confidence: 92,
    method: "Test"
  },
  {
    id: "s17",
    area: "Customer",
    docTitle: "6.2 Customer notification",
    docSub: "Sec 6",
    regulatory: "RBI Customer Service Master Direction — SMS/email confirmation within 30s of posting",
    whatToTest: "All IMPS debit/credit events generate timely SMS & email notifications",
    howToTest: [
      "Sample 50 IMPS transactions; cross-check SMS/email dispatch timestamps.",
      "Verify content includes amount, reference no., and helpline.",
      "Inspect SMS gateway exception report."
    ],
    dataRequired: ["SMS gateway log", "Email service log", "Customer master"],
    avail: "ok",
    confidence: 89,
    method: "Test"
  },
  {
    id: "s18",
    area: "Customer",
    docTitle: "6.3 Grievance redressal TAT",
    docSub: "Sec 6",
    regulatory: "RBI Integrated Ombudsman Scheme — grievance closure within 30 days",
    whatToTest: "Grievances tracked, escalated, and closed within RBI-mandated TAT",
    howToTest: [
      "Obtain grievance register for last quarter; compute open/closed counts.",
      "Sample 25 closed grievances; verify timestamps within 30 days.",
      "Inspect escalation matrix and Banking Ombudsman cases."
    ],
    dataRequired: ["Grievance register", "Ombudsman log", "Escalation matrix"],
    avail: "partial",
    confidence: 83,
    method: "System verify"
  },
  {
    id: "s19",
    area: "Customer",
    docTitle: "6.4 Refund process",
    docSub: "Sec 6",
    regulatory: "RBI TAT Harmonisation — refund within prescribed timelines with auto-compensation",
    whatToTest: "Customer-initiated refunds processed within SLA with appropriate compensation",
    howToTest: [
      "Sample 25 refund cases; measure days from initiation to credit.",
      "Verify compensation paid on SLA breach.",
      "Inspect refund queue ageing."
    ],
    dataRequired: ["Refund register", "Compensation log", "Queue ageing report"],
    avail: "partial",
    confidence: 85,
    method: "Test"
  },
  {
    id: "s20",
    area: "Regulatory",
    docTitle: "1.1 RBI authorisation & licensing",
    docSub: "Sec 1",
    regulatory: "PSS Act 2007 — authorisation as a payment system participant",
    whatToTest: "Bank holds valid RBI authorisation and conditions of licence are honoured",
    howToTest: [
      "Obtain authorisation certificate; verify validity and scope.",
      "Cross-check IMPS volume vs. licensed scope.",
      "Inspect any RBI inspection findings on authorisation."
    ],
    dataRequired: ["Authorisation cert", "Licence conditions", "RBI inspection report"],
    avail: "ok",
    confidence: 93,
    method: "Test"
  },
  {
    id: "s21",
    area: "Regulatory",
    docTitle: "1.2 NPCI participant agreement",
    docSub: "Sec 1",
    regulatory: "NPCI IMPS Participation Agreement — operational and dispute obligations",
    whatToTest: "Active agreement in place; obligations cascaded into operational SOPs",
    howToTest: [
      "Obtain executed participation agreement with NPCI.",
      "Map clauses to internal SOPs; identify gaps.",
      "Verify nodal officer designation and intimation to NPCI."
    ],
    dataRequired: ["NPCI agreement", "Internal SOP", "Nodal officer letter"],
    avail: "ok",
    confidence: 91,
    method: "System verify"
  },
  {
    id: "s22",
    area: "Regulatory",
    docTitle: "1.3 IMPS regulatory reporting",
    docSub: "Sec 1",
    regulatory: "RBI returns + NPCI MIS — monthly volume / value / incident reporting",
    whatToTest: "All required IMPS regulatory returns are filed accurately and on time",
    howToTest: [
      "Obtain reporting calendar; verify last 12 months of submissions.",
      "Sample 3 returns; reconcile to source data.",
      "Inspect any RBI/NPCI feedback on accuracy."
    ],
    dataRequired: ["Reporting calendar", "Filed returns", "Source MIS"],
    avail: "partial",
    confidence: 80,
    method: "Test"
  }
];

/* Pretty pill class for an Area string */
window.AREA_PILL = {
  "AML / KYC":     "pill-soft-blue",
  "Authentication":"pill-soft-purple",
  "Settlement":    "pill-soft-teal",
  "Cybersecurity": "pill-soft-rose",
  "Customer":      "pill-soft-amber",
  "Regulatory":    "pill"
};
