/* IDCPMS — auth gate, app bar, shared helpers */

(function () {
  const PUBLIC_PAGES = ["index.html", ""];
  const path = location.pathname.split("/").pop();

  function isAuthed() {
    try { return sessionStorage.getItem("idcpmsAuth") === "1"; }
    catch (_) { return false; }
  }

  function gate() {
    if (PUBLIC_PAGES.includes(path)) return;
    if (!isAuthed()) {
      location.replace("index.html");
    }
  }

  function logout() {
    try { sessionStorage.removeItem("idcpmsAuth"); } catch (_) {}
    location.replace("index.html");
  }

  function getUserName() {
    try { return sessionStorage.getItem("idcpmsUser") || "EMP-USER"; }
    catch (_) { return "EMP-USER"; }
  }

  function getInitials(name) {
    const s = String(name || "").trim();
    if (!s) return "U";
    // Try: split on non-alphanumeric → first char of first two parts
    const parts = s.split(/[^A-Za-z0-9]+/).filter(Boolean);
    if (parts.length >= 2) return (parts[0][0] + parts[1][0]).toUpperCase();
    return s.slice(0, 2).toUpperCase();
  }

  function renderAppBar(opts) {
    const host = document.getElementById("app-bar");
    if (!host) return;
    const userName = getUserName();
    const initials = getInitials(userName);
    const navLinks = (opts && opts.nav) || [
      { href: "upload.html",     label: "Upload" },
      { href: "workspace.html",  label: "Workspace" },
      { href: "guidelines.html", label: "Guidelines" }
    ];
    const here = (location.pathname.split("/").pop() || "").toLowerCase();
    const navHtml = navLinks.map(l =>
      `<a href="${l.href}" class="appbar-link${here === l.href.toLowerCase() ? " active" : ""}">${l.label}</a>`
    ).join("");

    host.innerHTML = `
      <div class="app-bar">
        <div class="inner">
          <span class="logo-tile tile-orange tile-sm">IC</span>
          <div class="title">IDCPMS <small>· IMPS Compliance &amp; Classification Suite</small></div>
          <nav class="appbar-nav">${navHtml}</nav>
          <div class="spacer"></div>
          <span class="user-chip">
            <span class="avatar">${escapeChip(initials)}</span>
            <span>${escapeChip(userName)} · Audit</span>
            <button id="logout-btn" title="Sign out">Sign out</button>
          </span>
        </div>
      </div>
    `;
    const btn = document.getElementById("logout-btn");
    if (btn) btn.addEventListener("click", logout);
  }

  function escapeChip(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
      "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
    }[c]));
  }

  function confidenceClass(score) {
    if (score >= 85) return "good";
    if (score >= 60) return "warn";
    return "bad";
  }

  function reviewFlag(score) {
    return score < 70;
  }

  /* Stub a download — used by export.html */
  function fakeDownload(filename, mime, body) {
    const blob = new Blob([body || ""], { type: mime || "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      URL.revokeObjectURL(url);
      a.remove();
    }, 100);
  }

  /* Position any open .menu-pop using fixed coords from its trigger button.
     Auto-flips upward when there isn't enough space below. */
  function positionOpenMenus(scope) {
    const root = scope || document;
    root.querySelectorAll(".menu-pop.open").forEach(menu => {
      const wrap = menu.parentElement; // .row-menu
      if (!wrap) return;
      const btn = wrap.querySelector(".menu-btn");
      if (!btn) return;
      const r = btn.getBoundingClientRect();
      // measure required height (clamped by max-height in CSS)
      menu.style.visibility = "hidden";
      menu.style.left = "-9999px";
      menu.style.top = "0";
      const needed = Math.min(menu.scrollHeight, 340);
      const width = Math.min(menu.offsetWidth || 240, 320);
      const spaceBelow = window.innerHeight - r.bottom;
      const spaceAbove = r.top;
      const flipUp = spaceBelow < needed + 12 && spaceAbove > spaceBelow;
      const top = flipUp
        ? Math.max(8, r.top - needed - 6)
        : Math.min(window.innerHeight - needed - 8, r.bottom + 6);
      const left = Math.max(8, Math.min(r.right - width, window.innerWidth - width - 8));
      menu.style.top = top + "px";
      menu.style.left = left + "px";
      menu.style.visibility = "";
    });
  }

  // Re-position on scroll / resize so the menu sticks to its trigger
  window.addEventListener("scroll", () => positionOpenMenus(), true);
  window.addEventListener("resize", () => positionOpenMenus());

  /* Click-outside helper for popovers */
  function attachOutsideClick(closeFn) {
    function handler(e) {
      const open = document.querySelector(".menu-pop.open");
      if (!open) return;
      if (open.contains(e.target)) return;
      const trigger = e.target.closest(".menu-btn");
      if (trigger && trigger.parentElement === open.parentElement) return;
      closeFn();
    }
    document.addEventListener("click", handler);
    return () => document.removeEventListener("click", handler);
  }

  window.IDCPMS = {
    gate,
    logout,
    renderAppBar,
    confidenceClass,
    reviewFlag,
    fakeDownload,
    attachOutsideClick,
    isAuthed,
    positionOpenMenus,
    getUserName,
    getInitials
  };

  /* Run gate immediately */
  gate();
})();
