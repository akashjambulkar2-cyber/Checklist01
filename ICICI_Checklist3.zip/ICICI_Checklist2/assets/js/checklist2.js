/* IDCPMS — Checklist 2 (Process classification table) renderer */

(function () {
  const state = {
    area: "all",
    avail: "all",
    search: "",
    openMenu: null
  };

  function dotsSvg() {
    return `<svg width="16" height="16" viewBox="0 0 16 16" fill="currentColor"><circle cx="8" cy="3" r="1.5"/><circle cx="8" cy="8" r="1.5"/><circle cx="8" cy="13" r="1.5"/></svg>`;
  }

  function getAreas() {
    const set = new Set(window.SECTIONS.map(s => s.area));
    return Array.from(set);
  }

  function visibleSections() {
    return window.SECTIONS.filter(s => {
      if (state.area !== "all" && s.area !== state.area) return false;
      if (state.avail !== "all" && s.avail !== state.avail) return false;
      if (state.search) {
        const q = state.search.toLowerCase();
        const blob = [
          s.area, s.docTitle, s.docSub, s.regulatory, s.whatToTest,
          (s.howToTest || []).join(" "), (s.dataRequired || []).join(" ")
        ].join(" ").toLowerCase();
        if (!blob.includes(q)) return false;
      }
      return true;
    });
  }

  function recomputeStats() {
    const visible = visibleSections();
    const ok = visible.filter(s => s.avail === "ok").length;
    const partial = visible.filter(s => s.avail === "partial").length;
    const gap = visible.filter(s => s.avail === "gap").length;
    const avg = visible.length === 0 ? 0 :
      Math.round(visible.reduce((s, x) => s + x.confidence, 0) / visible.length);
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    set("m-shown", visible.length);
    set("m-ok", ok);
    set("m-partial", partial);
    set("m-gap", gap);
    set("m-conf", visible.length === 0 ? "—" : (avg + "%"));
  }

  function availIcon(avail) {
    if (avail === "ok") return `<span class="avail-icon ok" title="Data available">✓</span>`;
    if (avail === "partial") return `<span class="avail-icon partial" title="Partial data">◐</span>`;
    return `<span class="avail-icon gap" title="Data gap">○</span>`;
  }

  function confCell(score, method) {
    const cls = window.IDCPMS.confidenceClass(score); // good/warn/bad
    const barCls = "conf-" + cls;
    const pillCls = cls === "good" ? "pill-soft-green" : cls === "warn" ? "pill-soft-amber" : "pill-soft-rose";
    return `
      <div class="conf-cell">
        <div class="conf-bar ${barCls}"><span style="width:${score}%"></span></div>
        <span class="pill ${pillCls}">${escapeHtml(method)}</span>
      </div>
    `;
  }

  function render() {
    const tbody = document.getElementById("cl2-tbody");
    if (!tbody) return;
    const rows = visibleSections().map(s => renderRow(s)).join("");
    tbody.innerHTML = rows || `<tr><td colspan="9" class="text-muted" style="padding:24px;text-align:center;">No sections match the current filters.</td></tr>`;
    bindRows();
    recomputeStats();
    if (window.IDCPMS && window.IDCPMS.positionOpenMenus) {
      requestAnimationFrame(() => window.IDCPMS.positionOpenMenus(tbody));
    }
  }

  function renderRow(s) {
    const flagged = window.IDCPMS.reviewFlag(s.confidence);
    const areaPill = window.AREA_PILL[s.area] || "pill";
    const menuOpen = state.openMenu === s.id;

    const headerOptions = getAreas().filter(a => a !== s.area)
      .map(a => `<button data-action="move-area" data-target="${escapeAttr(a)}">${escapeHtml(a)}</button>`)
      .join("");

    return `
      <tr class="${flagged ? "flagged" : ""}" data-id="${s.id}">
        <td><span class="pill ${areaPill}">${escapeHtml(s.area)}</span></td>
        <td>
          <div class="doc-name" contenteditable="true" spellcheck="false">${escapeHtml(s.docTitle)}</div>
          <div class="doc-sub">${escapeHtml(s.docSub)}</div>
        </td>
        <td>${escapeHtml(s.regulatory)}</td>
        <td contenteditable="true" spellcheck="false">${escapeHtml(s.whatToTest)}</td>
        <td>
          <ol class="how-list">
            ${(s.howToTest || []).map(h => `<li>${escapeHtml(h)}</li>`).join("")}
          </ol>
        </td>
        <td>
          <div class="data-list">
            ${(s.dataRequired || []).map(d => `<div>${escapeHtml(d)}</div>`).join("")}
          </div>
        </td>
        <td class="col-avail">${availIcon(s.avail)}</td>
        <td class="col-conf">${confCell(s.confidence, s.method)}</td>
        <td class="col-actions">
          <div class="row-menu">
            <button class="menu-btn" data-action="menu" aria-label="Row actions">${dotsSvg()}</button>
            <div class="menu-pop ${menuOpen ? "open" : ""}">
              <div class="submenu">
                <div class="label">Move to another header</div>
                ${headerOptions || `<div class="text-muted text-small" style="padding:6px 12px;">No other headers</div>`}
              </div>
              <div class="submenu">
                <button class="danger" data-action="delete">Delete module</button>
              </div>
            </div>
          </div>
        </td>
      </tr>
    `;
  }

  function bindRows() {
    const tbody = document.getElementById("cl2-tbody");
    if (!tbody) return;
    tbody.onclick = e => {
      const t = e.target.closest("[data-action]");
      if (!t) return;
      const tr = t.closest("tr");
      const id = tr && tr.dataset.id;
      const a = t.dataset.action;
      if (a === "menu") {
        e.stopPropagation();
        state.openMenu = state.openMenu === id ? null : id;
        render();
        return;
      }
      if (a === "move-area") {
        const target = t.dataset.target;
        const s = window.SECTIONS.find(x => x.id === id);
        if (s) s.area = target;
        state.openMenu = null;
        render();
        return;
      }
      if (a === "delete") {
        const idx = window.SECTIONS.findIndex(x => x.id === id);
        if (idx >= 0) window.SECTIONS.splice(idx, 1);
        state.openMenu = null;
        render();
        return;
      }
    };
    tbody.oninput = e => {
      const tr = e.target.closest("tr");
      if (!tr) return;
      const s = window.SECTIONS.find(x => x.id === tr.dataset.id);
      if (!s) return;
      if (e.target.matches(".doc-name")) s.docTitle = e.target.textContent;
      else if (e.target.matches("td[contenteditable]")) s.whatToTest = e.target.textContent;
    };
  }

  function bindFilters() {
    const areaSel = document.getElementById("f-area");
    const availSel = document.getElementById("f-avail");
    const search = document.getElementById("f-search");
    if (areaSel) {
      // populate
      areaSel.innerHTML = `<option value="all">All areas</option>` +
        getAreas().map(a => `<option value="${escapeAttr(a)}">${escapeHtml(a)}</option>`).join("");
      areaSel.onchange = () => { state.area = areaSel.value; render(); };
    }
    if (availSel) {
      availSel.onchange = () => { state.avail = availSel.value; render(); };
    }
    if (search) {
      search.oninput = () => { state.search = search.value.trim(); render(); };
    }
  }

  function escapeHtml(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, c => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
    }[c]));
  }
  function escapeAttr(s) { return escapeHtml(s); }

  document.addEventListener("click", e => {
    if (e.target.closest("[data-action='menu']")) return;
    if (e.target.closest(".menu-pop")) return;
    if (state.openMenu !== null) {
      state.openMenu = null;
      render();
    }
  });

  document.addEventListener("DOMContentLoaded", () => {
    bindFilters();
    render();
  });

  window.Checklist2 = { render, recomputeStats };
})();
